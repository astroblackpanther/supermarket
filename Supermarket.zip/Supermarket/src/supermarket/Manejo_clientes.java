
package supermarket;

import supermarket.Formulario;

/**
 *
 * @author mpaul
 */
public class Manejo_clientes {
    //El codigo se encuentra en la clase "formulario"
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Formulario formulario = new Formulario ();
        formulario.setVisible(true);
    }

  
    
    
}
